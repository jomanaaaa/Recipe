import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../models/favorite_meal.dart';
import '../models/meal.dart';
import '../services/database_service.dart';
import '../services/meal_api_service.dart';
import '../widgets/error_view.dart';

class MealDetailScreen extends StatefulWidget {
  final String mealId;
  const MealDetailScreen({super.key, required this.mealId});

  @override
  State<MealDetailScreen> createState() => _MealDetailScreenState();
}

class _MealDetailScreenState extends State<MealDetailScreen> {
  final _api = MealApiService();
  final _db = DatabaseService.instance;
  late Future<Meal> _future;
  FavoriteMeal? _existingFavorite;

  @override
  void initState() {
    super.initState();
    _future = _api.fetchMealById(widget.mealId);
    _checkFavorite();
  }

  Future<void> _checkFavorite() async {
    final fav = await _db.getFavoriteByMealId(widget.mealId);
    if (!mounted) return;
    setState(() => _existingFavorite = fav);
  }

  Future<void> _toggleFavorite(Meal meal) async {
    if (_existingFavorite != null) {
      await _db.deleteFavorite(_existingFavorite!.id!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Removed from favorites')),
      );
      setState(() => _existingFavorite = null);
    } else {
      await context.push('/favorite/new', extra: meal);
      _checkFavorite();
    }
  }

  void _retry() {
    setState(() => _future = _api.fetchMealById(widget.mealId));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Meal>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Scaffold(
              appBar: AppBar(),
              body: ErrorView(
                message: 'Could not load recipe.\n${snap.error}',
                onRetry: _retry,
              ),
            );
          }
          final meal = snap.data!;
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 240,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  title: Text(
                    meal.name,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 4)],
                    ),
                  ),
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(meal.thumb, fit: BoxFit.cover),
                      const DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, Colors.black87],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    Row(
                      children: [
                        _Chip(icon: Icons.restaurant, text: meal.category),
                        const SizedBox(width: 8),
                        _Chip(icon: Icons.public, text: meal.area),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Ingredients',
                      style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Card(
                      margin: EdgeInsets.zero,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          children: meal.ingredients
                              .map((ing) => Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 4),
                            child: Row(
                              children: [
                                const Icon(Icons.fiber_manual_record,
                                    size: 8),
                                const SizedBox(width: 12),
                                Expanded(child: Text(ing.name)),
                                Text(
                                  ing.measure,
                                  style: TextStyle(
                                      color: Colors.grey.shade700),
                                ),
                              ],
                            ),
                          ))
                              .toList(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Instructions',
                      style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    RichText(
                      text: TextSpan(
                        style: DefaultTextStyle.of(context)
                            .style
                            .copyWith(height: 1.5),
                        text: meal.instructions,
                      ),
                    ),
                    const SizedBox(height: 80),
                  ]),
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FutureBuilder<Meal>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) return const SizedBox.shrink();
          final isFav = _existingFavorite != null;
          return FloatingActionButton.extended(
            onPressed: () => _toggleFavorite(snap.data!),
            icon: Icon(isFav ? Icons.favorite : Icons.favorite_border),
            label: Text(isFav ? 'Saved' : 'Save'),
          );
        },
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Chip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.primaryContainer,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color.primary),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}