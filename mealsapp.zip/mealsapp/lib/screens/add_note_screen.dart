import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../models/favorite_meal.dart';
import '../models/meal.dart';
import '../services/database_service.dart';

class AddNoteScreen extends StatefulWidget {
  final FavoriteMeal? favorite;
  final Meal? meal;

  const AddNoteScreen({super.key, required this.favorite}) : meal = null;

  const AddNoteScreen.fromMeal({super.key, required this.meal})
      : favorite = null;

  @override
  State<AddNoteScreen> createState() => _AddNoteScreenState();
}

class _AddNoteScreenState extends State<AddNoteScreen> {
  final _formKey = GlobalKey<FormState>();
  final _noteController = TextEditingController();
  int _rating = 0;
  bool _saving = false;

  bool get _isEdit => widget.favorite != null;

  @override
  void initState() {
    super.initState();
    if (_isEdit) {
      _noteController.text = widget.favorite!.note;
      _rating = widget.favorite!.rating;
    }
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_rating == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please pick a rating')),
      );
      return;
    }
    setState(() => _saving = true);
    final db = DatabaseService.instance;

    if (_isEdit) {
      final updated = widget.favorite!.copyWith(
        note: _noteController.text.trim(),
        rating: _rating,
      );
      await db.updateFavorite(updated);
    } else {
      final fav = FavoriteMeal(
        mealId: widget.meal!.id,
        mealName: widget.meal!.name,
        mealThumb: widget.meal!.thumb,
        note: _noteController.text.trim(),
        rating: _rating,
        createdAt: DateTime.now(),
      );
      await db.addFavorite(fav);
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_isEdit ? 'Updated' : 'Saved to favorites')),
    );
    context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final name = _isEdit ? widget.favorite!.mealName : widget.meal!.name;
    final thumb = _isEdit ? widget.favorite!.mealThumb : widget.meal!.thumb;

    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit Note' : 'Save Recipe')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Card(
                  margin: EdgeInsets.zero,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            thumb,
                            width: 64,
                            height: 64,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 64,
                              height: 64,
                              color: Colors.grey.shade200,
                              child: const Icon(Icons.restaurant),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            name,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                const Text(
                  'Your rating',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (i) {
                    final filled = i < _rating;
                    return IconButton(
                      iconSize: 36,
                      icon: Icon(
                        filled ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                      ),
                      onPressed: () => setState(() => _rating = i + 1),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _noteController,
                  decoration: const InputDecoration(
                    labelText: 'Notes (optional)',
                    hintText: 'e.g., Use less salt next time',
                  ),
                  maxLines: 4,
                  maxLength: 200,
                  validator: (v) {
                    if (v != null && v.length > 200) {
                      return 'Keep notes under 200 characters';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: _saving
                      ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2),
                  )
                      : const Icon(Icons.save),
                  label: Text(_isEdit ? 'Save Changes' : 'Save to Favorites'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}