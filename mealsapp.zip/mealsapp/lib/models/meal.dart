class MealSummary {
  final String id;
  final String name;
  final String thumb;

  const MealSummary({
    required this.id,
    required this.name,
    required this.thumb,
  });

  factory MealSummary.fromJson(Map<String, dynamic> json) {
    return MealSummary(
      id: json['idMeal'] ?? '',
      name: json['strMeal'] ?? '',
      thumb: json['strMealThumb'] ?? '',
    );
  }
}

class Meal {
  final String id;
  final String name;
  final String thumb;
  final String category;
  final String area;
  final String instructions;
  final String? youtube;
  final List<MealIngredient> ingredients;
  final List<String> tags;

  const Meal({
    required this.id,
    required this.name,
    required this.thumb,
    required this.category,
    required this.area,
    required this.instructions,
    required this.ingredients,
    required this.tags,
    this.youtube,
  });

  factory Meal.fromJson(Map<String, dynamic> json) {
    final ingredients = <MealIngredient>[];
    for (var i = 1; i <= 20; i++) {
      final name = json['strIngredient$i'] as String?;
      final measure = json['strMeasure$i'] as String?;
      if (name != null && name.trim().isNotEmpty) {
        ingredients.add(MealIngredient(
          name: name.trim(),
          measure: (measure ?? '').trim(),
        ));
      }
    }

    final tagsRaw = json['strTags'] as String?;
    final tags = (tagsRaw == null || tagsRaw.trim().isEmpty)
        ? <String>[]
        : tagsRaw.split(',').map((e) => e.trim()).toList();

    return Meal(
      id: json['idMeal'] ?? '',
      name: json['strMeal'] ?? '',
      thumb: json['strMealThumb'] ?? '',
      category: json['strCategory'] ?? '',
      area: json['strArea'] ?? '',
      instructions: json['strInstructions'] ?? '',
      youtube: json['strYoutube'] as String?,
      ingredients: ingredients,
      tags: tags,
    );
  }
}

class MealIngredient {
  final String name;
  final String measure;

  const MealIngredient({required this.name, required this.measure});
}