class MealCategory {
  final String id;
  final String name;
  final String thumb;
  final String description;

  const MealCategory({
    required this.id,
    required this.name,
    required this.thumb,
    required this.description,
  });

  factory MealCategory.fromJson(Map<String, dynamic> json) {
    return MealCategory(
      id: json['idCategory'] ?? '',
      name: json['strCategory'] ?? '',
      thumb: json['strCategoryThumb'] ?? '',
      description: json['strCategoryDescription'] ?? '',
    );
  }
}