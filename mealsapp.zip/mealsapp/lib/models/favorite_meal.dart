class FavoriteMeal {
  final int? id;
  final String mealId;
  final String mealName;
  final String mealThumb;
  final String note;
  final int rating;
  final DateTime createdAt;

  const FavoriteMeal({
    this.id,
    required this.mealId,
    required this.mealName,
    required this.mealThumb,
    required this.note,
    required this.rating,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'mealId': mealId,
      'mealName': mealName,
      'mealThumb': mealThumb,
      'note': note,
      'rating': rating,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory FavoriteMeal.fromMap(Map<String, dynamic> map) {
    return FavoriteMeal(
      id: map['id'] as int?,
      mealId: map['mealId'] as String,
      mealName: map['mealName'] as String,
      mealThumb: map['mealThumb'] as String,
      note: (map['note'] as String?) ?? '',
      rating: (map['rating'] as int?) ?? 0,
      createdAt: DateTime.parse(map['createdAt'] as String),
    );
  }

  FavoriteMeal copyWith({String? note, int? rating}) {
    return FavoriteMeal(
      id: id,
      mealId: mealId,
      mealName: mealName,
      mealThumb: mealThumb,
      note: note ?? this.note,
      rating: rating ?? this.rating,
      createdAt: createdAt,
    );
  }
}