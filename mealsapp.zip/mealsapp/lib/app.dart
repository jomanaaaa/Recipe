import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'models/category.dart';
import 'models/favorite_meal.dart';
import 'models/meal.dart';
import 'screens/add_note_screen.dart';
import 'screens/home_screen.dart';
import 'screens/meal_detail_screen.dart';
import 'screens/meals_by_category_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

class MealsApp extends StatelessWidget {
  const MealsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Meals',
      theme: AppTheme.light,
      debugShowCheckedModeBanner: false,
      routerConfig: _router,
    );
  }
}

final GoRouter _router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (_, __) => const SplashScreen(),
    ),
    GoRoute(
      path: '/profile',
      builder: (_, state) {
        final isSetup = (state.extra as bool?) ?? false;
        return ProfileScreen(isSetup: isSetup);
      },
    ),
    GoRoute(
      path: '/home',
      builder: (_, __) => const HomeScreen(),
    ),
    GoRoute(
      path: '/category',
      builder: (_, state) {
        final category = state.extra as MealCategory;
        return MealsByCategoryScreen(category: category);
      },
    ),
    GoRoute(
      path: '/meal/:id',
      builder: (_, state) {
        final id = state.pathParameters['id']!;
        return MealDetailScreen(mealId: id);
      },
    ),
    GoRoute(
      path: '/favorite/new',
      builder: (_, state) {
        final meal = state.extra as Meal;
        return AddNoteScreen.fromMeal(meal: meal);
      },
    ),
    GoRoute(
      path: '/favorite/edit',
      builder: (_, state) {
        final fav = state.extra as FavoriteMeal;
        return AddNoteScreen(favorite: fav);
      },
    ),
  ],
);