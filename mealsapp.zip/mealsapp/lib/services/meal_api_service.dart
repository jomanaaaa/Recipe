import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/category.dart';
import '../models/meal.dart';

class MealApiService {
  static const String _base = 'https://www.themealdb.com/api/json/v1/1';

  Future<List<MealCategory>> fetchCategories() async {
    final res = await http.get(Uri.parse('$_base/categories.php'));
    if (res.statusCode != 200) {
      throw Exception('Failed to load categories (HTTP ${res.statusCode})');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final list = (data['categories'] as List?) ?? const [];
    return list
        .map((e) => MealCategory.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<MealSummary>> fetchMealsByCategory(String category) async {
    final url = Uri.parse('$_base/filter.php?c=${Uri.encodeQueryComponent(category)}');
    final res = await http.get(url);
    if (res.statusCode != 200) {
      throw Exception('Failed to load meals (HTTP ${res.statusCode})');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final list = (data['meals'] as List?) ?? const [];
    return list
        .map((e) => MealSummary.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Meal> fetchMealById(String id) async {
    final res = await http.get(Uri.parse('$_base/lookup.php?i=$id'));
    if (res.statusCode != 200) {
      throw Exception('Failed to load recipe (HTTP ${res.statusCode})');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final list = (data['meals'] as List?) ?? const [];
    if (list.isEmpty) {
      throw Exception('Recipe not found');
    }
    return Meal.fromJson(list.first as Map<String, dynamic>);
  }

  Future<List<MealSummary>> searchMealsByName(String query) async {
    final url = Uri.parse('$_base/search.php?s=${Uri.encodeQueryComponent(query)}');
    final res = await http.get(url);
    if (res.statusCode != 200) {
      throw Exception('Search failed (HTTP ${res.statusCode})');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final list = (data['meals'] as List?) ?? const [];
    return list.map((e) {
      final m = e as Map<String, dynamic>;
      return MealSummary.fromJson({
        'idMeal': m['idMeal'],
        'strMeal': m['strMeal'],
        'strMealThumb': m['strMealThumb'],
      });
    }).toList();
  }
}