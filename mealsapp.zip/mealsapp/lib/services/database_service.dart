import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/favorite_meal.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _db;

  Future<Database> get database async {
    return _db ??= await _open();
  }

  Future<Database> _open() async {
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'meals.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE favorites(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mealId TEXT NOT NULL UNIQUE,
            mealName TEXT NOT NULL,
            mealThumb TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            rating INTEGER NOT NULL DEFAULT 0,
            createdAt TEXT NOT NULL
          )
        ''');
      },
    );
  }

  Future<int> addFavorite(FavoriteMeal fav) async {
    final db = await database;
    final map = fav.toMap()..remove('id');
    return db.insert(
      'favorites',
      map,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<FavoriteMeal>> getAllFavorites() async {
    final db = await database;
    final rows = await db.query('favorites', orderBy: 'createdAt DESC');
    return rows.map(FavoriteMeal.fromMap).toList();
  }

  Future<FavoriteMeal?> getFavoriteByMealId(String mealId) async {
    final db = await database;
    final rows = await db.query(
      'favorites',
      where: 'mealId = ?',
      whereArgs: [mealId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return FavoriteMeal.fromMap(rows.first);
  }

  Future<int> updateFavorite(FavoriteMeal fav) async {
    final db = await database;
    return db.update(
      'favorites',
      fav.toMap(),
      where: 'id = ?',
      whereArgs: [fav.id],
    );
  }

  Future<int> deleteFavorite(int id) async {
    final db = await database;
    return db.delete('favorites', where: 'id = ?', whereArgs: [id]);
  }
}